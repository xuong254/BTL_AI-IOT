#include <iostream>

int main() {
    int num1, num2;
    std::cout << "Nh?p s? th? nh?t (3 ch? s?): ";
    std::cin >> num1;
    std::cout << "Nh?p s? th? hai (3 ch? s?): ";
    std::cin >> num2;

    if (num1 < 100 || num1 > 999 || num2 < 100 || num2 > 999) {
        std::cout << "Vui l?ng nh?p s? c� 3 ch? s?.\n";
        return 1;
    }

    int a = num1 / 100;
    int b = (num1 % 100) / 10;
    int c = num1 % 10;

    int x = num2 / 100;
    int y = (num2 % 100) / 10;
    int z = num2 % 10;

    int u = c * z;
    int v = b * z + c * y;
    int w = a * z + b * y;
    int t = a * y;

    int result = u + v * 10 + w * 100 + t * 100;

    std::cout << "K?t qu? c?a ph�p nh�n " << num1 << " v� " << num2 << " l�: " << result << std::endl;

    return 0;
}
