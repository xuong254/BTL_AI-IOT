#include <iostream>
#include <cmath>

int main() {
    const double PI = 3.141592653589793238463;
    int height = 10; // Chi?u cao c?a h?nh tr�i tim

    for (int y = height / 2; y >= -height / 2; --y) {
        for (int x = -height / 2; x <= height / 2; ++x) {
            double distance = std::sqrt(x * x + y * y);
            if (distance <= height / 2.0) {
                std::cout << "* ";
            } else {
                std::cout << "  ";
            }
        }
        std::cout << std::endl;
    }

    return 0;
}
